package com.example.bankruptcy_support_app_bot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BankruptcySupportAppBotApplicationTests {

	@Test
	void contextLoads() {
	}

}
