package com.example.bankruptcy_support_app_bot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BankruptcySupportAppBotApplication {

	public static void main(String[] args) {
		SpringApplication.run(BankruptcySupportAppBotApplication.class, args);
	}

}
